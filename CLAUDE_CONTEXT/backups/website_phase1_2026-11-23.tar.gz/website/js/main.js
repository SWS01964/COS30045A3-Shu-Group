/* Loads the CSVs, fills prose numbers from the data, draws every chart, redraws on resize. */
(function () {
  const files = {
    rates: 'idea1_rates', index: 'idea1_index_long', heat: 'idea2_heatmap_change',
    pop: 'idea2_age_population_change', annual: 'idea2_roaduser_age_annual', sev: 'idea2_age_severity'
  };

  function fillProse(d) {
    const r11 = d.rates.find((r) => r.year === 2011), r21 = d.rates.find((r) => r.year === 2021);
    const idx = (s) => d.index.find((q) => q.series === s && q.year === 2021).index_2011;
    const heat = (u, a) => d.heat.find((c) => c.road_user === u && c.age_group === a).pct_change_3yr;
    const pop = (a) => d.pop.find((p) => p.age_group === a).pct_change_3yr;
    const pp = (u, a) => ((1 + heat(u, a) / 100) / (1 + pop(a) / 100) - 1) * 100;
    const v = {
      hosp21: Viz.fmtInt(r21.hospitalisations), perDay: Math.round(r21.hospitalisations / 365),
      ratio21: Math.round(r21.hosp_per_death), ratio11: Math.round(r11.hosp_per_death),
      deaths21: Viz.fmtInt(r21.road_deaths), deaths11: Viz.fmtInt(r11.road_deaths),
      hospPct: Math.round(idx('hospitalisations') - 100), popPct: Math.round(idx('population') - 100),
      deathsPct: (100 - idx('road_deaths')).toFixed(1),
      deathRateFall: Math.round((1 - r21.deaths_per_100k / r11.deaths_per_100k) * 100),
      rate11: Math.round(r11.hosp_per_100k), rate21: Math.round(r21.hosp_per_100k),
      dr11: r11.deaths_per_100k.toFixed(2), dr21: r21.deaths_per_100k.toFixed(2),
      cyc6574: Math.round(heat('Pedal cyclist', '65-74')), cyc75: Math.round(heat('Pedal cyclist', '75+')),
      cycpp6574: Math.round(pp('Pedal cyclist', '65-74')), cycpp75: Math.round(pp('Pedal cyclist', '75+')),
      pop6574: Math.round(pop('65-74')), pop75: Math.round(pop('75+')),
      cyc4064: Math.round(heat('Pedal cyclist', '40-64'))
    };
    document.querySelectorAll('[data-fill]').forEach((el) => { if (v[el.dataset.fill] !== undefined) el.textContent = v[el.dataset.fill]; });
  }

  Promise.all(Object.values(files).map((f) => d3.csv('data/' + f + '.csv', d3.autoType))).then((arr) => {
    const d = {};
    Object.keys(files).forEach((k, i) => { d[k] = arr[i]; });
    fillProse(d);
    const els = {unit: document.getElementById('chart-unit'), lines: document.getElementById('chart-lines'), heat: document.getElementById('chart-heat'),
      trend: document.getElementById('chart-trend'), sev: document.getElementById('chart-sev')};
    Charts.unit.render(els.unit, d);
    Charts.lines.init(els.lines, d);
    Charts.heatmap.init(els.heat, els.trend, d);
    Charts.severity.render(els.sev, d);
    let w = window.innerWidth;
    window.addEventListener('resize', Viz.debounce(() => {
      if (window.innerWidth === w) return; // ignore mobile address-bar height changes
      w = window.innerWidth;
      Viz.tip.hide();
      Charts.unit.render(els.unit, d);
      Charts.lines.render(els.lines, d);
      Charts.heatmap.redraw();
      Charts.severity.render(els.sev, d);
    }, 200));
  }).catch((err) => {
    console.error(err);
    const e = document.createElement('div');
    e.className = 'error';
    e.textContent = 'The charts could not load their data. If you opened this file directly, serve the folder with a web server instead (see README).';
    document.querySelector('main').prepend(e);
  });
})();
