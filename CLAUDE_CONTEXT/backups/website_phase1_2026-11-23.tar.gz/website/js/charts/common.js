/* Shared helpers: colours, formats, text wrapping, tooltip. */
window.Viz = (function () {
  const css = (n) => getComputedStyle(document.documentElement).getPropertyValue(n).trim();
  const reduced = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const MINUS = '−';

  const fmtInt = d3.format(',');
  const signed = (v, dp) => {
    const r = +Math.abs(v).toFixed(dp || 0);
    return (v < 0 && r !== 0 ? MINUS : (r === 0 ? '' : '+')) + r.toLocaleString('en-AU', {minimumFractionDigits: dp || 0, maximumFractionDigits: dp || 0});
  };
  const ageLabel = (a) => a.replace('-', '–');

  // Wrap `str` into tspans inside a <text> selection. Returns number of lines.
  function wrap(text, str, width, lh) {
    lh = lh || 15;
    const x = text.attr('x') || 0, y = text.attr('y') || 0;
    text.text(null);
    let line = [], n = 1;
    let ts = text.append('tspan').attr('x', x).attr('y', y);
    str.split(/\s+/).forEach((w) => {
      line.push(w);
      ts.text(line.join(' '));
      if (ts.node().getComputedTextLength() > width && line.length > 1) {
        line.pop(); ts.text(line.join(' ')); line = [w];
        ts = text.append('tspan').attr('x', x).attr('y', y).attr('dy', n * lh).text(w);
        n++;
      }
    });
    return n;
  }

  const tipEl = d3.select('body').append('div').attr('class', 'tip').attr('role', 'tooltip');
  const tip = {
    show(html, cx, cy) {
      tipEl.html(html).classed('on', true);
      const n = tipEl.node(), w = n.offsetWidth, h = n.offsetHeight;
      let left = cx + 14, top = cy - h - 12;
      if (left + w > window.innerWidth - 8) left = cx - w - 14;
      if (left < 8) left = 8;
      if (top < 8) top = cy + 18;
      tipEl.style('left', left + 'px').style('top', top + 'px');
    },
    hide() { tipEl.classed('on', false); }
  };
  document.addEventListener('pointerdown', (e) => { if (!e.target.closest('.chart')) tip.hide(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') tip.hide(); });

  function debounce(fn, ms) { let t; return function () { clearTimeout(t); t = setTimeout(fn, ms); }; }

  function fillTable(sel, caption, head, rows) {
    const t = d3.select(sel);
    t.html('');
    t.append('caption').text(caption);
    t.append('thead').append('tr').selectAll('th').data(head).join('th').attr('scope', 'col').text((d) => d);
    t.append('tbody').selectAll('tr').data(rows).join('tr').selectAll('td').data((d) => d).join('td').text((d) => d);
  }

  return {css, reduced, MINUS, fmtInt, signed, ageLabel, wrap, tip, debounce, fillTable};
})();
