# Beyond the road toll (website)

Static D3 v7 data story. No build step, no CDN (D3 7.9.0 is vendored).

## Run locally
    python3 -m http.server 8765 --directory website
then open http://localhost:8765/ (opening index.html from disk will not work: browsers block `fetch` of the CSVs).

## File map
- `index.html` page and prose (numbers marked `data-fill` are recomputed from the CSVs by `js/main.js`)
- `css/style.css` design tokens (CSS custom properties) and layout
- `js/main.js` loads data, fills prose numbers, draws charts, debounced redraw on resize
- `js/charts/common.js` shared helpers (tooltip, text wrap, formats, data tables)
- `js/charts/unit.js` Chart 1B; `lines.js` Chart 1A; `heatmap.js` Chart 2A (+ trend line); `severity.js` Chart 2B
- `js/vendor/d3.min.js` D3 7.9.0
- `data/` the six CSVs used; refresh with `sh processing/sync_website_data.sh`

## Deploy to Swinburne Mercury
Copy the whole `website/` folder (all files, keep the structure) into your Mercury web directory. All paths are relative.

## TODO
Replace `[Team names]` / `[names]` and the GitHub placeholder URL (`YOUR-ORG/YOUR-REPO`) in `index.html`; confirm the BITRE licence version.
